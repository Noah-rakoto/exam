<?php
header("location: page/login.php");
exit();
?>