<?php
require_once '../inc/connexion.php';
require_once '../inc/fonctions.php';
session_start();

$nom = $_POST['nom'];
$date_naissance = $_POST['date'];
$genre = $_POST['genre'];
$email = $_POST['email'];
$ville = $_POST['ville'];
$mdp = $_POST['password'];
if (creerMembre($nom, $date_naissance, $genre, $email, $ville, $mdp)) {
    header("location: liste.php");
    exit();
} else {
    echo "Erreur lors de l'inscription. Veuillez réessayer.";
}

?>