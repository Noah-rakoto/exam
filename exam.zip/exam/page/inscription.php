<?php

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/boostrap-icon/bootstrap-icons.css">
    <title>Document</title>
</head>

<body>
    <header>

    </header>
    <main>
        <form action="traitement_inscription.php" method="post">
            <label for="">
                <p>Nom</p>
            </label>
            <input type="text" name="nom" id="" required placeholder="Nom">
            <label for="">
                <p>Email</p>
            </label>
            <input type="email" name="email" id="" required placeholder="Email">
            <label for="">
                <p>Mot de passe</p>
            </label>
            <input type="password" name="password" id="" required placeholder="Mot de passe">
            <label for="">
                <p>Date de naissance</p>
            </label>
            <input type="date" name="date" id="" required placeholder="date de naissance">
            <label for="">
                <p>Genre</p>
            </label>
            <select name="genre" id="genre" required>
                <option value="M">Masculin</option>
                <option value="F">Féminin</option>
            </select>
            <label for="">
                <p>Ville</p>
            </label>
            <input type="text" name="ville" id="ville" required placeholder="Ville">
            <button type="submit">S'inscrire</button>



            <p>Deja un compte? <a href="login.php">Se connecter</a></p>
        </form>


    </main>
    <footer>

    </footer>
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>