<?php
require_once '../inc/fonctions.php';
session_start();
$id_co = $_SESSION['id'];
$categorie_filtre = $_GET['categorie'] ?? null;
$objets = $categorie_filtre ? filtrer_objets_par_categorie($categorie_filtre) : lister_tous_objets();
$categories = get_categories();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des objets</title>
</head>

<body>
    <main>
        <h1>Liste des objets</h1>

        <!-- Formulaire de filtrage simplifié -->
        <div class="filtre-container">
            <form method="get">
                <select name="categorie">
                    <option value="">Toutes catégories</option>
                    <?php foreach ($categories as $categorie): ?>
                        <option value="<?= htmlspecialchars($categorie['nom_categorie']) ?>"
                            <?= ($categorie_filtre === $categorie['nom_categorie']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($categorie['nom_categorie']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Filtrer</button>
                <?php if ($categorie_filtre): ?>
                    <a href="?">Tout afficher</a>
                <?php endif; ?>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Objet</th>
                    <th>Catégorie</th>
                    <th>Propriétaire</th>
                    <th>Statut</th>
                    <th>Retour prévu</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($objets as $objet): ?>
                    <tr>
                        <td>
                            <a href="fiche_obj.php?nom=<?= urlencode($objet['nom_objet']) ?>" class="object-link">
                                <?= htmlspecialchars($objet['nom_objet']) ?>
                            </a>
                        </td>
                        <td><?= htmlspecialchars($objet['nom_categorie']) ?></td>
                        <td><?= htmlspecialchars($objet['proprietaire']) ?></td>
                        <td><?= htmlspecialchars($objet['statut']) ?></td>
                        <td><?= $objet['date_retour'] ?? '-' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>

</html>