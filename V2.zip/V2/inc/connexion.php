 <?php
    function dbconnect()
    {
        static $connect = null;

        if ($connect === null) {

            $connect = mysqli_connect('localhost', 'root', '', 'emprunt');
            // $connect = mysqli_connect('localhost', 'ETU004547', 'hp9wriRv', 'db_s2_ETU004547');

            if (!$connect) {
                die('Erreur de connexion à la base de données : ' . mysqli_connect_error());
            }

            mysqli_set_charset($connect, 'utf8mb4');
        }

        return $connect;
    }
    ?>