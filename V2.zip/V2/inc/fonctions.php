<?php
require_once '../inc/connexion.php';

function creerMembre($nom, $date_naissance, $genre, $email, $ville, $mdp)
{
    $conn = dbconnect();
    $sql = "INSERT INTO emp_membre (nom, date_naissance, genre, email, ville, mdp, image_profil)
            VALUES ('$nom', '$date_naissance', '$genre', '$email', '$ville', '$mdp', 'assets/image/default.png')";
    $result = mysqli_query($conn, $sql);
    mysqli_close($conn);

    return $result;
}
function verifycompte($email, $mdp)
{
    $conn = dbconnect();
    $req = "SELECT * FROM emp_membre WHERE email = '$email' AND mdp = '$mdp'";
    $result = mysqli_query($conn, $req);
    return mysqli_num_rows($result) > 0;
}
function getidbyemail($email)
{
    $conn = dbconnect();
    $req = "SELECT id_membre FROM emp_membre WHERE email = '$email'";
    $result = mysqli_query($conn, $req);
    if ($row = mysqli_fetch_assoc($result)) {
        return $row['id'];
    }
    return null;
}
function listeObjets()
{
    $conn = dbconnect();
    $req = "SELECT * FROM emp_view_objet_and_membre_and_emprunt";
    $result = mysqli_query($conn, $req);
    $objets = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $objets[] = $row;
    }
    return $objets;
}
/**
 * Récupère toutes les catégories disponibles
 */
function get_categories()
{
    $conn = dbconnect();
    $req = "SELECT * FROM emp_categorie_objet ORDER BY nom_categorie";
    $result = mysqli_query($conn, $req);

    $categories = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row;
    }
    return $categories;
}

/**
 * Liste tous les objets avec leur statut
 */
function lister_tous_objets()
{
    $conn = dbconnect();
    $req = "SELECT * FROM emp_view_objets_complet";
    $result = mysqli_query($conn, $req);

    $objets = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $objets[] = $row;
    }
    return $objets;
}

/**
 * Filtre les objets par catégorie
 */
function filtrer_objets_par_categorie($categorie)
{
    $conn = dbconnect();
    $req = "SELECT * FROM emp_view_objets_complet 
            WHERE nom_categorie = '" . mysqli_real_escape_string($conn, $categorie) . "'";
    $result = mysqli_query($conn, $req);

    $objets = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $objets[] = $row;
    }
    return $objets;
}
function get_by_name($name)
{
    $conn = dbconnect();
    $req = "SELECT * FROM emp_membre WHERE nom = '" . mysqli_real_escape_string($conn, $name) . "'";
    $result = mysqli_query($conn, $req);
    if ($row = mysqli_fetch_assoc($result)) {
        return $row['id_membre'];
    }
    return null;
}
function get_objet_by_id_with_view($id_objet)
{
    $conn = dbconnect();
    if (!$conn) {
        return ['error' => 'Database connection failed'];
    }

    // Secure the input by forcing it to be an integer
    $id_objet = intval($id_objet);
    $req = "SELECT * FROM vue_objet_complet_inner WHERE id_objet = $id_objet";

    $result = mysqli_query($conn, $req);

    // Check if query failed
    if ($result === false) {
        return ['error' => 'Database query failed: ' . mysqli_error($conn)];
    }

    // Check if no results found
    if (mysqli_num_rows($result) === 0) {
        return ['error' => 'No object found with ID: ' . $id_objet];
    }

    $objets = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $objets[] = $row;
    }

    mysqli_free_result($result);
    return $objets;
}

function get_id_by_name($name)
{
    $conn = dbconnect();
    $req = "SELECT id_objet FROM emp_objet WHERE nom_objet = '" . mysqli_real_escape_string($conn, $name) . "'";
    $result = mysqli_query($conn, $req);
    if ($row = mysqli_fetch_assoc($result)) {
        return $row['id_objet'];
    }
    return null;
}
